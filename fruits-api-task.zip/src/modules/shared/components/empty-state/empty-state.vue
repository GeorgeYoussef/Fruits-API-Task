<template>
  <div class="dataFoundContainer">
    <img src="@/assets/img/NoDataFound.png" alt="No data found" />
  </div>
</template>

<style lang="scss" scoped>
.dataFoundContainer {
  display: flex;
  justify-content: center;
  align-items: center;
  img {
    max-width: 100%;
    width: 50%;
  }
}
</style>
