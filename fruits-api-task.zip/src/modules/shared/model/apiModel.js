module.exports = {
  apiModel: {
    status: 0,
    message: "",
    data: "",
    error: "",
  },
  requestType: {
    add: 1,
    delete: 4,
    error: 10,
  },
};
